﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SamSungManager
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

            dataGridView2.DataSource = Data.Users;

            dataGridView2.Columns[nameof(Users.Id)].HeaderText = "사용자 ID";
            dataGridView2.Columns[nameof(Users.Name)].HeaderText = "사용자명";
            dataGridView2.Columns[nameof(Users.Roll)].HeaderText = "부서";

            Text = "사용자 관리";

            dataGridView2.DataSource = Data.Users;
            dataGridView2.CurrentCellChanged += DataGridView2_CurrentCellChanged;

            button1.Click += (sender, e) =>
            {
                try
                {
                    if (Data.Users.Exists((x) => x.Id == int.Parse(textBox1.Text)))
                    {
                        MessageBox.Show("사용자 ID가 겹칩니다.");
                    }
                    else
                    {
                        Users user = new Users()
                        {
                            Id = int.Parse(textBox1.Text),
                            Name = textBox2.Text,
                            Roll = textBox3.Text
                        };
                        Data.Users.Add(user);

                        dataGridView2.DataSource = null;
                        dataGridView2.DataSource = Data.Users;
                        Data.Save();
                    }
                }
                catch (Exception exception)
                {

                }
            };

            button2.Click += (sender, e) =>
            {
                try
                {
                    Users user = Data.Users.Single((x) => x.Id == int.Parse(textBox1.Text));
                    user.Name = textBox2.Text;


                    dataGridView2.DataSource = null;
                    dataGridView2.DataSource = Data.Users;
                    Data.Save();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("존재하지 않는 사용자입니다.");
                }
            };

            button3.Click += (sender, e) =>
            {
                try
                {
                    Users user = Data.Users.Single((x) => x.Id == int.Parse(textBox1.Text));
                    Data.Users.Remove(user);

                    dataGridView2.DataSource = null;
                    dataGridView2.DataSource = Data.Users;
                    Data.Save();
                }
                catch (Exception exception)
                {
                    MessageBox.Show("존재하지 않는 사용자입니다.");
                }
            };
        }
        private void DataGridView2_CurrentCellChanged(object? sender, EventArgs e)
        {
            try
            {
                Users user = dataGridView2.CurrentRow.DataBoundItem as Users;
                textBox1.Text = user.Id.ToString();
                textBox2.Text = user.Name;
                textBox3.Text = user.Roll;
            }
            catch (Exception exception) { }
        }
    }
}
