using Microsoft.VisualBasic.ApplicationServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SamSungManager
{
    public partial class Form1 : Form
    {
        private static readonly HttpClient httpClient = new HttpClient();
        public Form1()
        {
            InitializeComponent();


            //button3.Click += button3_Click;
            dataGridView1.DataSource = Data.Equipments;

            dataGridView1.Columns[nameof(Equipments.E_id)].HeaderText = "����ID";
            dataGridView1.Columns[nameof(Equipments.E_sep)].HeaderText = "�����з�";
            dataGridView1.Columns[nameof(Equipments.E_name)].HeaderText = "������";
            dataGridView1.Columns[nameof(Equipments.E_status)].HeaderText = "��������";
            dataGridView1.Columns[nameof(Equipments.UserId)].HeaderText = "�뿩��ID";
            dataGridView1.Columns[nameof(Equipments.UserName)].HeaderText = "�뿩���̸�";
            dataGridView1.Columns[nameof(Equipments.isBorrowed)].HeaderText = "�뿩����";
            dataGridView1.Columns[nameof(Equipments.BorrowedAt)].HeaderText = "�뿩����";

            dataGridView2.DataSource = Data.Users;

            dataGridView2.Columns[nameof(Users.Id)].HeaderText = "����� ID";
            dataGridView2.Columns[nameof(Users.Name)].HeaderText = "����ڸ�";
            dataGridView2.Columns[nameof(Users.Roll)].HeaderText = "�μ�";


            Text = "���� ����";

            label5.Text = Data.Equipments.Count.ToString();
            label6.Text = Data.Users.Count.ToString();
            label7.Text = Data.Equipments.Where((x) => x.isBorrowed).Count().ToString();
            label8.Text = Data.Equipments.Where((x) =>
            {
                return x.isBorrowed && x.BorrowedAt.AddDays(7) < DateTime.Now;
            }).Count().ToString();

            dataGridView1.DataSource = Data.Equipments;
            dataGridView2.DataSource = Data.Users;
            dataGridView1.CurrentCellChanged += dataGridView1_CurrentCellChanged;
            dataGridView2.CurrentCellChanged += dataGridView2_CurrentCellChanged;

            //button1.Click += button1_Click;
            //button2.Click += button2_Click;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = Data.Equipments;
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            new Form3().ShowDialog();
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = Data.Users;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("����ID�� �Է����ּ���.");
            }
            else if (textBox3.Text.Trim() == "")
            {
                MessageBox.Show("����� ID�� �Է����ּ���.");
            }
            else
            {
                try
                {
                    Equipments equipment = Data.Equipments.Single((x) => x.E_id == textBox1.Text);
                    if (equipment.isBorrowed)
                    {
                        MessageBox.Show("�̹� �뿩 ���� �����Դϴ�.");
                    }
                    else
                    {
                        Users user = Data.Users.Single((x) => x.Id.ToString() == textBox3.Text);
                        equipment.UserId = user.Id;
                        equipment.UserName = user.Name;
                        equipment.isBorrowed = true;
                        equipment.BorrowedAt = DateTime.Now;

                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = Data.Equipments;
                        Data.Save();
                        MessageBox.Show("\"" + equipment.E_name + "\"��/��\"" + user.Name + "\"�Բ� �뿩�Ǿ����ϴ�.");
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("�������� �ʴ� ���� �Ǵ� ������Դϴ�.");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("����ID�� �Է����ּ���.");
            }
            else
            {
                try
                {
                    Equipments equipment = Data.Equipments.Single((x) => x.E_id == textBox1.Text);
                    if (!equipment.isBorrowed)
                    {
                        MessageBox.Show("�뿩 ���°� �ƴմϴ�.");
                    }
                    else
                    {
                        Users user = Data.Users.Single((x) => x.Id.ToString() == textBox3.Text);
                        equipment.UserId = 0;
                        equipment.UserName = "";
                        equipment.isBorrowed = false;
                        equipment.BorrowedAt = DateTime.Now;

                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = Data.Equipments;
                        Data.Save();
                        if (equipment.BorrowedAt.AddDays(7) > DateTime.Now)
                        {
                            MessageBox.Show("\"" + equipment.E_name + "\"��/�� ��ü ���·� �ݳ��Ǿ����ϴ�.");
                        }
                        else
                        {
                            MessageBox.Show("\"" + equipment.E_name + "\"��/�� �ݳ��Ǿ����ϴ�.");
                        }
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("�������� �ʴ� ���� �Ǵ� ������Դϴ�.");
                }
            }
        }

        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            var row = dataGridView1.CurrentRow;
            if (row == null || row.IsNewRow) return;
            if (row.DataBoundItem is not Equipments equipment) return;

            textBox1.Text = equipment.E_id ?? "";
            textBox2.Text = equipment.E_name ?? "";
        }
        private void dataGridView2_CurrentCellChanged(object sender, EventArgs e)
        {
            var row = dataGridView2.CurrentRow;
            if (row == null || row.IsNewRow) return;
            if (row.DataBoundItem is not Users user) return;

            textBox3.Text = user.Id.ToString();
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            string question = textBox4.Text.Trim();

            if (string.IsNullOrWhiteSpace(question))
            {
                MessageBox.Show("������ �Է��ϼ���.", "�˸�",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // ��ư �ߺ� Ŭ�� ����
            button3.Enabled = false;
            richTextBox1.AppendText($"[����]\r\n{question}\r\n\r\n[�亯 ��� ��...]\r\n\r\n");

            try
            {
                string answer = await AskOllamaAsync(question);

                // ���� ���亯 ��� ��...�� ���� ��� ���� �亯�� �ְ� �ʹٸ�
                richTextBox1.AppendText("[�亯]\r\n" + answer + "\r\n\r\n");
            }
            catch (Exception ex)
            {
                richTextBox1.AppendText("[���� �߻�]\r\n" + ex.Message + "\r\n\r\n");
            }
            finally
            {
                button3.Enabled = true;
            }
        }

        private async Task<string> AskOllamaAsync(string question)
        {
            // Ollama Chat API (stream:false ���)
            var requestObj = new
            {
                model = "gemma3:4b",   // ��� ���� �� �̸����� ����
                messages = new[]
                {
                    new {
                        role = "user",
                        content = question
                    },
                    new{role="system",content="�ʴ� �Ｚ�߰��� ���� �������̴�. " +
                    "�ʴ� �� �̻� �ΰ����� ��� ���� �ƴϾ�." + "��Ģ: �ʴ� ����� \"�˰ڽ��ϴ�. ���� ���� �Ｚ�߰��� ���� �������Դϴ�\" ��� ������ �״�� ����ϸ� �� �ȴ�."
                    }
                },
                stream = false
            };

            string url = "http://localhost:11434/api/chat";

            string json = JsonSerializer.Serialize(requestObj);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage response = await httpClient.PostAsync(url, content);
            response.EnsureSuccessStatusCode();

            string responseJson = await response.Content.ReadAsStringAsync();

            // ���� JSON �Ľ� (Ollama chat ���� ���� ����)
            // {
            //   "model": "...",
            //   "message": { "role": "assistant", "content": "..." },
            //   ...
            // }
            using var doc = JsonDocument.Parse(responseJson);
            var root = doc.RootElement;

            if (root.TryGetProperty("message", out JsonElement messageElement) &&
                messageElement.TryGetProperty("content", out JsonElement contentElement))
            {
                return contentElement.GetString();
            }
            else
            {
                // Ȥ�� ������ �ٸ� ��� ��ü JSON�� ��ȯ�ؼ� �����
                return "���� ������ ����� �ٸ��ϴ�.\r\n" + responseJson;
            }
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            toolStripMenuItem3.Click += (s, e) => this.Close();

        }
    }
}
