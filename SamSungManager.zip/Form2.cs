﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SamSungManager
{
    public partial class Form2 : Form
    {
        private static RadioButton? FindCheckedRadio(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is RadioButton rb && rb.Checked) return rb;

                var found = FindCheckedRadio(c);
                if (found != null) return found;
            }
            return null;
        }

        public Form2()
        {
            InitializeComponent();

            dataGridView1.DataSource = Data.Equipments;

            dataGridView1.Columns[nameof(Equipments.E_id)].HeaderText = "차량ID";
            dataGridView1.Columns[nameof(Equipments.E_sep)].HeaderText = "차량분류";
            dataGridView1.Columns[nameof(Equipments.E_name)].HeaderText = "차량명";
            dataGridView1.Columns[nameof(Equipments.E_status)].HeaderText = "차량상태";
            dataGridView1.Columns[nameof(Equipments.UserId)].HeaderText = "대여자ID";
            dataGridView1.Columns[nameof(Equipments.UserName)].HeaderText = "대여자이름";
            dataGridView1.Columns[nameof(Equipments.isBorrowed)].HeaderText = "대여여부";
            dataGridView1.Columns[nameof(Equipments.BorrowedAt)].HeaderText = "대여일자";

            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(new object[] { "지게차(FL)", "크레인(CR)", "운반차량(TR)" });
            comboBox1.SelectedIndex = 0;


            Text = "차량 관리";

            dataGridView1.DataSource = Data.Equipments;
            dataGridView1.CurrentCellChanged += DataGridView1_CurrentCellChanged;

            button1.Click += (sender, e) =>
            {
                try
                {
                    if (Data.Equipments.Exists((x) => x.E_id == textBox1.Text))
                    {
                        MessageBox.Show("이미 존재하는 차량입니다.");
                    }
                    else
                    {
                        Equipments equipment = new Equipments()
                        {
                            E_id = textBox1.Text,
                            E_sep = comboBox1.SelectedItem?.ToString() ?? "",
                            E_name = textBox3.Text,
                            E_status = FindCheckedRadio(groupBox1)?.Text ?? ""
                        };
                        Data.Equipments.Add(equipment);

                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = Data.Equipments;
                        Data.Save();
                    }
                }
                catch (Exception exception)
                {
                    MessageBox.Show("존재하지 않는 차량입니다.");
                }
            };

            button2.Click += (sender, e) =>
            {
                try
                {
                    Equipments equipment = Data.Equipments.Single((x) => x.E_id == textBox1.Text);
                    equipment.E_sep = comboBox1.SelectedItem?.ToString() ?? "";
                    equipment.E_name = textBox3.Text;
                    equipment.E_status = FindCheckedRadio(groupBox1)?.Text ?? "";

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = Data.Equipments;
                    Data.Save();
                }
                catch (Exception exception)
                {

                }
            };

            button3.Click += (sender, e) =>
            {
                try
                {
                    Equipments equipment = Data.Equipments.Single((x) => x.E_id == textBox1.Text);
                    Data.Equipments.Remove(equipment);

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = Data.Equipments;
                    Data.Save();
                }
                catch (Exception exception)
                {

                }
            };

        }

        

        private void DataGridView1_CurrentCellChanged(object? sender, EventArgs e)
        {
            try
            {
                Equipments equipment = dataGridView1.CurrentRow.DataBoundItem as Equipments;
                textBox1.Text = equipment.E_id;
                comboBox1.Text = equipment.E_sep;
                textBox3.Text = equipment.E_name;
                FindCheckedRadio(groupBox1)?.Text = equipment.E_status;
            }
            catch (Exception exception) { }
        }
    }
}
