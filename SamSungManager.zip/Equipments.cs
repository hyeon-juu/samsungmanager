﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SamSungManager
{
    internal class Equipments
    {

        public string E_id { get; set; }
        public string E_sep { get; set; }
        public string E_name { get; set; }
        public string E_status { get; set; }

        public int UserId { get; set; }
        public string UserName { get; set; }
        public bool isBorrowed { get; set; }
        public DateTime BorrowedAt { get; set; }

    }
}
