﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SamSungManager
{
    internal class Users
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Roll { get; set; }

    }
}
