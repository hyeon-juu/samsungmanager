﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace SamSungManager
{
    internal class Data
    {
        public static List<Equipments> Equipments = new List<Equipments>();
        public static List<Users> Users = new List<Users>();

        static Data()
        {
            Load();
        }

        public static void Load()
        {
            try
            {
                string equipmentsOutput = File.ReadAllText(@"./Equipments.xml");
                XElement equipmentsXElement = XElement.Parse(equipmentsOutput);
                Equipments = (from item in equipmentsXElement.Descendants("equipment")
                         select new Equipments()
                         {
                             E_id = item.Element("id").Value,
                             E_sep = item.Element("sep").Value,
                             E_name = item.Element("name").Value,
                             E_status = item.Element("status").Value,
                             UserId = int.Parse(item.Element("userId").Value),
                             UserName = item.Element("userName").Value,
                             BorrowedAt = DateTime.Parse(item.Element("borrowedAt").Value),
                             isBorrowed = item.Element("isBorrowed").Value != "0" ? true : false
                         }).ToList<Equipments>();
                string usersOutput = File.ReadAllText(@"./Users.xml");
                XElement usersXElement = XElement.Parse(usersOutput);
                Users = (from item in usersXElement.Descendants("user")
                         select new Users()
                         {
                             Id = int.Parse(item.Element("id").Value),
                             Name = item.Element("name").Value,
                             Roll = item.Element("name").Value
                         }).ToList<Users>();
            }
            catch (FileNotFoundException exception)
            {
                Save();
            }
        }
        public static void Save()
        {
            string booksOutput = "";
            booksOutput += "<equipments>\n";
            foreach (var item in Equipments)
            {
                booksOutput += "<equipment>\n";
                booksOutput += "    <id>" + item.E_id + "</id>\n";
                booksOutput += "    <sep>" + item.E_sep + "</sep>\n";
                booksOutput += "    <name>" + item.E_name + "</name>\n";
                booksOutput += "    <status>" + item.E_status + "</status>\n";
                booksOutput += "    <userId>" + item.UserId + "</userId>\n";
                booksOutput += "    <userName>" + item.UserName + "</userName>\n";
                booksOutput += "    <borrowedAt>" + item.BorrowedAt.ToLongDateString() + "</borrowedAt>\n";
                booksOutput += "    <isBorrowed>" + (item.isBorrowed ? 1 : 0) + "</isBorrowed>\n";
                booksOutput += "</equipment>\n";
            }
            booksOutput += "</equipments>\n";

            string usersOutput = "";
            usersOutput += "<users>\n";
            foreach (var item in Users)
            {
                usersOutput += "<user>\n";
                usersOutput += "    <id>" + item.Id + "</id>\n";
                usersOutput += "    <name>" + item.Name + "</name>\n";
                usersOutput += "    <roll>" + item.Roll + "</roll>\n";
                usersOutput += "</user>\n";
            }
            usersOutput += "</users>\n";

            File.WriteAllText(@"./Equipments.xml", booksOutput);
            File.WriteAllText(@"./Users.xml", usersOutput);
        }
    }
}
